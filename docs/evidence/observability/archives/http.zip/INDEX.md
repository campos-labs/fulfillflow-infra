# Evidências: http

Consulta saudável, erros preparatórios e sequência controlada; snapshots cumulativos por trace_id.

Os manifestos identificam fontes, hashes e exclusões; review.json é conferência derivada.
Protocolos identificam as referências medidas. Falhas preparatórias não são casos aprovados.
Sem imagens, bancos, segredos ou garantia de recriar o ambiente.

Relatório e reprodutor: docs/OBSERVABILITY_EVALUATION.md e
docs/evidence/observability/reproduce.py no repositório fulfillflow-infra.
Este pacote permite leitura independente; a conferência executável usa o checkout.
